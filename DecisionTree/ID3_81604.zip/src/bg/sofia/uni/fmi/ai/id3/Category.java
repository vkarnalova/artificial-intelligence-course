package bg.sofia.uni.fmi.ai.id3;

public enum Category {
	NO_RECURRENCE_EVENTS, RECURRENCE_EVENTS
}
