package bg.sofia.uni.fmi.ai.id3;

public enum FeatureName {
	AGE, MENOPAUSE, TUMOR_SIZE, INV_NODES, NODE_CAPS, DEG_MALIG, BREAST, BREAST_QUAD, IRRADIAT
}
