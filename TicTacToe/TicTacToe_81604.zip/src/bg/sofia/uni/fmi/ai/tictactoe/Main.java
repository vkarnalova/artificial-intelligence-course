package bg.sofia.uni.fmi.ai.tictactoe;

public class Main {
	public static void main(String... args) {
		new Game().startGame();
	}
}
